module.exports = {
  content: ["./src/scss/**/*.scss", "./src/**/*.html"],
  theme: { extend: {} },
  variants: { extend: {} },
  plugins: [],
};
